"""Run one small proposed RIS-EVS-OFDM estimation demo."""

from __future__ import annotations

import pathlib
import sys

import numpy as np

if __package__ in (None, ""):
    project_root = pathlib.Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(project_root))
    from src.channel_model import (
        add_awgn,
        channel_components,
        generate_scene,
        synthesize_raw_tensor,
    )
    from src.config import default_config
    from src.estimators import initialize_from_hankel, refine_global_raw, structured_refinement
    from src.metrics import position_rmse, rmse_tensor
    from src.tensor_utils import hankelize_frequency
    from src.utils import scipy_is_available
else:
    from .channel_model import (
        add_awgn,
        channel_components,
        generate_scene,
        synthesize_raw_tensor,
    )
    from .config import default_config
    from .estimators import initialize_from_hankel, refine_global_raw, structured_refinement
    from .metrics import position_rmse, rmse_tensor
    from .tensor_utils import hankelize_frequency
    from .utils import scipy_is_available


def main() -> None:
    """Generate one channel sample, estimate it, and print final metrics."""
    config = default_config()
    seed = config["seed"]
    snr_db = config["SNR_dB"]
    rng = np.random.default_rng(seed)

    scene = generate_scene(config, rng)
    true_components = channel_components(
        scene,
        scene["p_u_true"],
        scene["delta_t_true"],
        scene["gamma_true"],
        scene["eta_true"],
    )
    y_true = synthesize_raw_tensor(true_components, scene["beta_true"])
    y_noisy, _ = add_awgn(y_true, snr_db, rng)
    z_noisy = hankelize_frequency(y_noisy, scene["P"])

    assert y_true.shape == (scene["I"], scene["N"], scene["T"])
    assert y_noisy.shape == y_true.shape
    assert z_noisy.shape == (scene["I"], scene["P"], scene["L"], scene["T"])

    print("Single proposed run")
    print(f"seed = {seed}")
    print(f"SNR_dB = {snr_db:g}")
    print(
        "dimensions = "
        f"K={scene['K']}, I={scene['I']}, N={scene['N']}, "
        f"P={scene['P']}, L={scene['L']}, T={scene['T']}, M_R={scene['M_R']}"
    )
    if not scipy_is_available():
        print("optimizer_note = scipy.optimize not found; using deterministic fallback optimizer")

    estimate = initialize_from_hankel(z_noisy, scene, config)
    print(f"initial_Z_RMSE_noisy = {estimate['initial_z_residual']:.6e}")

    estimate, residuals = structured_refinement(z_noisy, scene, config, estimate)
    for idx, residual in enumerate(residuals, start=1):
        print(f"structured_iter_{idx}_Z_RMSE_noisy = {residual:.6e}")

    final = refine_global_raw(y_noisy, scene, config, estimate)
    print(
        "raw_global_optimizer = "
        f"{final['optimizer']['method']}, converged={final['optimizer']['success']}, "
        f"n_eval={final['optimizer']['n_eval']}"
    )
    print(f"raw_global_optimizer_message = {final['optimizer']['message']}")

    y_hat = final["Y_hat"]
    assert y_hat.shape == y_true.shape
    rmse_y = rmse_tensor(y_hat, y_true)
    rmse_p = position_rmse(final["p_u"], scene["p_u_true"])

    print(f"Y_true shape = {y_true.shape}")
    print(f"Y_noisy shape = {y_noisy.shape}")
    print(f"Y_hat shape = {y_hat.shape}")
    print(f"RMSE_Y = {rmse_y:.6e}")
    print(f"UE_position_RMSE_m = {rmse_p:.6e}")


if __name__ == "__main__":
    main()
